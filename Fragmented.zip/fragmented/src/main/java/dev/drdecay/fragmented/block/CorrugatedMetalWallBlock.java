package dev.drdecay.fragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/** Thin 2px panel that can be placed anywhere (no support needed). */
public class CorrugatedMetalWallBlock extends HorizontalFacingBlock {
	public static final MapCodec<CorrugatedMetalWallBlock> CODEC = createCodec(CorrugatedMetalWallBlock::new);
	private static final VoxelShape N = Block.createCuboidShape(0, 0, 0, 16, 16, 2);
	private static final VoxelShape S = Block.createCuboidShape(0, 0, 14, 16, 16, 16);
	private static final VoxelShape E = Block.createCuboidShape(14, 0, 0, 16, 16, 16);
	private static final VoxelShape W = Block.createCuboidShape(0, 0, 0, 2, 16, 16);

	public CorrugatedMetalWallBlock(Settings s) { super(s); setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH)); }
	@Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }
	@Override protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(FACING); }
	@Override public BlockState getPlacementState(ItemPlacementContext ctx) { return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing()); }
	@Override protected VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) {
		return switch (s.get(FACING)) { case SOUTH -> S; case EAST -> E; case WEST -> W; default -> N; };
	}
}
