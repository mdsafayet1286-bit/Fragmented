package dev.drdecay.fragmented.item;

import dev.drdecay.fragmented.Fragmented;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

public class TinMaterial implements ToolMaterial {
	public static final TinMaterial INSTANCE = new TinMaterial();
	public int getDurability() { return 180; }
	public float getMiningSpeedMultiplier() { return 5.0f; }
	public float getAttackDamage() { return 1.5f; }
	public TagKey<Block> getInverseTag() { return BlockTags.INCORRECT_FOR_STONE_TOOL; }
	public int getEnchantability() { return 16; }
	public Ingredient getRepairIngredient() { return Ingredient.ofItems(Fragmented.TIN_INGOT); }
}
