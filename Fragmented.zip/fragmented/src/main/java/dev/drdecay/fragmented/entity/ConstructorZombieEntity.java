package dev.drdecay.fragmented.entity;

import dev.drdecay.fragmented.Fragmented;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.SpawnReason;
import net.minecraft.world.ServerWorldAccess;
import org.jetbrains.annotations.Nullable;

public class ConstructorZombieEntity extends ZombieEntity {
	public ConstructorZombieEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }

	@Override
	public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty diff, SpawnReason reason, @Nullable EntityData data) {
		EntityData d = super.initialize(world, diff, reason, data);
		equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
		equipStack(EquipmentSlot.MAINHAND, new ItemStack(Fragmented.TIN_PICKAXE));
		return d;
	}
}
