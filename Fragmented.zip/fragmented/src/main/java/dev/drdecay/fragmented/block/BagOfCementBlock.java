package dev.drdecay.fragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/** Slab-height placeable bag, 2 blocks of footprint feel (long side 14px, short 10px). */
public class BagOfCementBlock extends HorizontalFacingBlock {
	public static final MapCodec<BagOfCementBlock> CODEC = createCodec(BagOfCementBlock::new);
	private static final VoxelShape NS = Block.createCuboidShape(3, 0, 1, 13, 6, 15);
	private static final VoxelShape EW = Block.createCuboidShape(1, 0, 3, 15, 6, 13);

	public BagOfCementBlock(Settings s) { super(s); setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH)); }
	@Override protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }
	@Override protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(FACING); }
	@Override public BlockState getPlacementState(ItemPlacementContext ctx) { return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing()); }
	@Override protected VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) {
		return s.get(FACING).getAxis() == Direction.Axis.X ? EW : NS;
	}
}
