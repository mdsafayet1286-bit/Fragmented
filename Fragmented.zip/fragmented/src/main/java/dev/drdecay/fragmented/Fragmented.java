package dev.drdecay.fragmented;

import dev.drdecay.fragmented.block.*;
import dev.drdecay.fragmented.entity.*;
import dev.drdecay.fragmented.item.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.*;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

import java.util.ArrayList;
import java.util.List;

public class Fragmented implements ModInitializer {
	public static final String MOD_ID = "fragmented";
	public static final List<ItemStack> TAB = new ArrayList<>();

	public static Identifier id(String p) { return Identifier.of(MOD_ID, p); }

	private static <T extends Block> T block(String name, T b) {
		Registry.register(Registries.BLOCK, id(name), b);
		BlockItem bi = new BlockItem(b, new Item.Settings());
		Registry.register(Registries.ITEM, id(name), bi);
		TAB.add(new ItemStack(bi));
		return b;
	}
	private static <T extends Item> T item(String name, T i) {
		Registry.register(Registries.ITEM, id(name), i);
		TAB.add(new ItemStack(i));
		return i;
	}
	private static AbstractBlock.Settings stone() { return AbstractBlock.Settings.copy(Blocks.STONE); }
	private static AbstractBlock.Settings bricks() { return AbstractBlock.Settings.copy(Blocks.BRICKS); }
	private static AbstractBlock.Settings wood() { return AbstractBlock.Settings.copy(Blocks.OAK_PLANKS); }

	// ---- Items
	public static Item RAW_TIN, TIN_INGOT, BAMBOO_STICK, POWDERED_CEMENT;
	public static Item TIN_SWORD, TIN_PICKAXE, TIN_AXE, TIN_SHOVEL, TIN_HOE, CONSTRUCTOR_ZOMBIE_SPAWN_EGG;

	// ---- Blocks
	public static Block TIN_ORE, DEEPSLATE_TIN_ORE, CORRUGATED_METAL_WALL, BAMBOO_PILLAR, METAL_STRING;
	public static Block CEMENT_BLOCK, SOLID_CEMENT, SOLID_CEMENT_STAIRS, SOLID_CEMENT_SLAB, SOLID_CEMENT_WALL, BAG_OF_CEMENT;
	public static Block WHITE_BRICKS, WHITE_BRICK_STAIRS, WHITE_BRICK_SLAB, WHITE_BRICK_WALL;
	public static Block FRAGMENTED_CONCRETE, FRAGMENTED_CONCRETE_POWDER;
	public static Block FRAGWOOD_LOG, STRIPPED_FRAGWOOD_LOG, FRAGWOOD_WOOD, STRIPPED_FRAGWOOD_WOOD, FRAGWOOD_PLANKS, FRAGWOOD_LEAVES;

	// ---- Entities
	public static EntityType<ConstructorZombieEntity> CONSTRUCTOR_ZOMBIE;
	public static EntityType<CementBagEntity> CEMENT_BAG;

	@Override
	public void onInitialize() {
		TIN_ORE = block("tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.IRON_ORE)));
		DEEPSLATE_TIN_ORE = block("deepslate_tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_IRON_ORE)));
		RAW_TIN = item("raw_tin", new Item(new Item.Settings()));
		TIN_INGOT = item("tin_ingot", new Item(new Item.Settings()));
		BAMBOO_STICK = item("bamboo_stick", new Item(new Item.Settings()));
		POWDERED_CEMENT = item("powdered_cement", new Item(new Item.Settings()));

		CORRUGATED_METAL_WALL = block("corrugated_metal_wall", new CorrugatedMetalWallBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).nonOpaque()));
		BAMBOO_PILLAR = block("bamboo_pillar", new PaneBlock(AbstractBlock.Settings.copy(Blocks.IRON_BARS)));
		METAL_STRING = block("metal_string", new MetalStringBlock(AbstractBlock.Settings.copy(Blocks.TRIPWIRE).noCollision().nonOpaque()));

		SOLID_CEMENT = block("solid_cement", new Block(stone()));
		CEMENT_BLOCK = block("cement_block", new ConcretePowderBlock(SOLID_CEMENT, AbstractBlock.Settings.copy(Blocks.GRAVEL)));
		SOLID_CEMENT_STAIRS = block("solid_cement_stairs", new StairsBlock(SOLID_CEMENT.getDefaultState(), stone()));
		SOLID_CEMENT_SLAB = block("solid_cement_slab", new SlabBlock(stone()));
		SOLID_CEMENT_WALL = block("solid_cement_wall", new WallBlock(stone()));
		BAG_OF_CEMENT = Registry.register(Registries.BLOCK, id("bag_of_cement"), new BagOfCementBlock(AbstractBlock.Settings.copy(Blocks.WHITE_WOOL).nonOpaque()));
		item("bag_of_cement", new BagOfCementItem(BAG_OF_CEMENT, new Item.Settings()));

		WHITE_BRICKS = block("white_bricks", new Block(bricks()));
		WHITE_BRICK_STAIRS = block("white_brick_stairs", new StairsBlock(WHITE_BRICKS.getDefaultState(), bricks()));
		WHITE_BRICK_SLAB = block("white_brick_slab", new SlabBlock(bricks()));
		WHITE_BRICK_WALL = block("white_brick_wall", new WallBlock(bricks()));

		FRAGMENTED_CONCRETE = block("fragmented_concrete", new Block(AbstractBlock.Settings.copy(Blocks.GRAY_CONCRETE)));
		FRAGMENTED_CONCRETE_POWDER = block("fragmented_concrete_powder", new ConcretePowderBlock(FRAGMENTED_CONCRETE, AbstractBlock.Settings.copy(Blocks.GRAY_CONCRETE_POWDER)));

		FRAGWOOD_LOG = block("fragwood_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)));
		STRIPPED_FRAGWOOD_LOG = block("stripped_fragwood_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_LOG)));
		FRAGWOOD_WOOD = block("fragwood_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)));
		STRIPPED_FRAGWOOD_WOOD = block("stripped_fragwood_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_WOOD)));
		FRAGWOOD_PLANKS = block("fragwood_planks", new Block(wood()));
		FRAGWOOD_LEAVES = block("fragwood_leaves", new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES)));

		TIN_SWORD = item("tin_sword", new SwordItem(TinMaterial.INSTANCE, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(TinMaterial.INSTANCE, 3, -2.4f))));
		TIN_PICKAXE = item("tin_pickaxe", new PickaxeItem(TinMaterial.INSTANCE, new Item.Settings().attributeModifiers(PickaxeItem.createAttributeModifiers(TinMaterial.INSTANCE, 1.0f, -2.8f))));
		TIN_AXE = item("tin_axe", new AxeItem(TinMaterial.INSTANCE, new Item.Settings().attributeModifiers(AxeItem.createAttributeModifiers(TinMaterial.INSTANCE, 6.0f, -3.1f))));
		TIN_SHOVEL = item("tin_shovel", new ShovelItem(TinMaterial.INSTANCE, new Item.Settings().attributeModifiers(ShovelItem.createAttributeModifiers(TinMaterial.INSTANCE, 1.5f, -3.0f))));
		TIN_HOE = item("tin_hoe", new HoeItem(TinMaterial.INSTANCE, new Item.Settings().attributeModifiers(HoeItem.createAttributeModifiers(TinMaterial.INSTANCE, -2.0f, -1.0f))));

		CONSTRUCTOR_ZOMBIE = Registry.register(Registries.ENTITY_TYPE, id("constructor_zombie"),
			EntityType.Builder.create(ConstructorZombieEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(8).build("constructor_zombie"));
		FabricDefaultAttributeRegistry.register(CONSTRUCTOR_ZOMBIE, ZombieEntity.createZombieAttributes());
		CEMENT_BAG = Registry.register(Registries.ENTITY_TYPE, id("cement_bag"),
			EntityType.Builder.<CementBagEntity>create(CementBagEntity::new, SpawnGroup.MISC).dimensions(0.25f, 0.25f).maxTrackingRange(4).trackingTickInterval(10).build("cement_bag"));
		CONSTRUCTOR_ZOMBIE_SPAWN_EGG = item("constructor_zombie_spawn_egg", new SpawnEggItem(CONSTRUCTOR_ZOMBIE, 0x8a8a8a, 0xe0a030, new Item.Settings()));

		Registry.register(Registries.ITEM_GROUP, id("main"), FabricItemGroup.builder()
			.icon(() -> new ItemStack(TIN_INGOT))
			.displayName(Text.translatable("itemGroup.fragmented"))
			.entries((ctx, entries) -> TAB.forEach(entries::add)).build());

		// World generation
		addFeature("ore_tin", GenerationStep.Feature.UNDERGROUND_ORES, false);
		addFeature("ore_cement", GenerationStep.Feature.UNDERGROUND_ORES, false);
		BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_FOREST), GenerationStep.Feature.VEGETAL_DECORATION,
			RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("fragwood_tree")));
	}

	private static void addFeature(String name, GenerationStep.Feature step, boolean unused) {
		BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), step, RegistryKey.of(RegistryKeys.PLACED_FEATURE, id(name)));
	}
}
