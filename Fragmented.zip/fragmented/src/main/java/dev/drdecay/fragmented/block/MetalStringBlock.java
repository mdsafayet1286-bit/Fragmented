package dev.drdecay.fragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

/** Thin wire laid on the ground. If it sits between two powered redstone sources it becomes hot. */
public class MetalStringBlock extends Block {
	public static final MapCodec<MetalStringBlock> CODEC = createCodec(MetalStringBlock::new);
	private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 1, 16);

	public MetalStringBlock(Settings settings) { super(settings); }
	@Override protected MapCodec<? extends Block> getCodec() { return CODEC; }
	@Override protected VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, net.minecraft.block.ShapeContext c) { return SHAPE; }

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return world.getBlockState(pos.down()).isSideSolidFullSquare(world, pos.down(), Direction.UP);
	}

	@Override
	protected BlockState getStateForNeighborUpdate(BlockState state, Direction dir, BlockState n, net.minecraft.world.WorldAccess w, BlockPos pos, BlockPos np) {
		return dir == Direction.DOWN && !canPlaceAt(state, w, pos) ? Blocks.AIR.getDefaultState() : state;
	}

	private static boolean powered(BlockState s) {
		return s.isOf(Blocks.REDSTONE_BLOCK) || (s.isOf(Blocks.REDSTONE_WIRE) && s.get(RedstoneWireBlock.POWER) > 0)
			|| (s.isOf(Blocks.REDSTONE_TORCH) && s.get(RedstoneTorchBlock.LIT));
	}

	public static boolean isHot(World world, BlockPos pos) {
		return (powered(world.getBlockState(pos.east())) && powered(world.getBlockState(pos.west())))
			|| (powered(world.getBlockState(pos.north())) && powered(world.getBlockState(pos.south())));
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (world.isClient || !(entity instanceof LivingEntity) || !isHot(world, pos)) return;
		entity.damage(world.getDamageSources().inFire(), 2.0f);
		entity.setOnFireFor(4);
		BlockPos above = pos.up();
		if (world.random.nextInt(4) == 0 && world.getBlockState(above).isAir()) {
			world.setBlockState(above, AbstractFireBlock.getState(world, above));
		}
	}
}
