package dev.drdecay.fragmented.item;

import dev.drdecay.fragmented.entity.CementBagEntity;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Right-click a block to place it, right-click in the air to throw it. */
public class BagOfCementItem extends BlockItem {
	public BagOfCementItem(Block block, Settings settings) { super(block, settings); }

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.NEUTRAL, 0.5f, 0.6f);
		if (!world.isClient) {
			CementBagEntity e = new CementBagEntity(world, player);
			e.setItem(stack);
			e.setVelocity(player, player.getPitch(), player.getYaw(), 0.0f, 1.2f, 1.0f);
			world.spawnEntity(e);
		}
		player.incrementStat(Stats.USED.getOrCreateStat(this));
		stack.decrementUnlessCreative(1, player);
		return TypedActionResult.success(stack, world.isClient());
	}
}
