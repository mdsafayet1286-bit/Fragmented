package dev.drdecay.fragmented.entity;

import dev.drdecay.fragmented.Fragmented;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class CementBagEntity extends ThrownItemEntity {
	public CementBagEntity(EntityType<? extends ThrownItemEntity> type, World world) { super(type, world); }
	public CementBagEntity(World world, LivingEntity owner) { super(Fragmented.CEMENT_BAG, owner, world); }

	@Override protected Item getDefaultItem() { return Fragmented.BAG_OF_CEMENT.asItem(); }

	@Override
	protected void onEntityHit(EntityHitResult hit) {
		super.onEntityHit(hit);
		hit.getEntity().damage(getDamageSources().thrown(this, getOwner()), 4.0f);
	}

	@Override
	protected void onCollision(HitResult hit) {
		super.onCollision(hit);
		if (getWorld() instanceof ServerWorld sw) {
			sw.spawnParticles(new DustParticleEffect(new Vector3f(0.75f, 0.75f, 0.75f), 3.0f),
				getX(), getY(), getZ(), 60, 0.6, 0.6, 0.6, 0.02);
			discard();
		}
	}
}
