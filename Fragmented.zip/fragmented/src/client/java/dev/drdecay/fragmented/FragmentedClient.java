package dev.drdecay.fragmented;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.render.entity.ZombieEntityRenderer;

public class FragmentedClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		BlockRenderLayerMap.INSTANCE.putBlock(Fragmented.FRAGWOOD_LEAVES, RenderLayer.getCutoutMipped());
		BlockRenderLayerMap.INSTANCE.putBlock(Fragmented.BAMBOO_PILLAR, RenderLayer.getCutoutMipped());
		BlockRenderLayerMap.INSTANCE.putBlock(Fragmented.METAL_STRING, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(Fragmented.CORRUGATED_METAL_WALL, RenderLayer.getCutout());
		EntityRendererRegistry.register(Fragmented.CONSTRUCTOR_ZOMBIE, ZombieEntityRenderer::new);
		EntityRendererRegistry.register(Fragmented.CEMENT_BAG, FlyingItemEntityRenderer::new);
	}
}
