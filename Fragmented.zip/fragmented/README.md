# Fragmented (Fabric 1.21.1) by Dr.Decay
    unzip Fragmented.zip
    cd fragmented
    bash build.sh
Needs JDK 21 + internet. Output: Fragmented-1.0.0.jar -> put in mods folder with Fabric API.
