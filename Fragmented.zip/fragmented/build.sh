#!/usr/bin/env bash
# One-command build: bash build.sh
set -e
command -v java >/dev/null || { echo "Java 21 not found. Install JDK 21 first."; exit 1; }
if [ ! -f gradlew ]; then
  if ! command -v gradle >/dev/null; then
    echo "Downloading Gradle..."
    curl -L -o /tmp/gradle.zip https://services.gradle.org/distributions/gradle-8.8-bin.zip
    unzip -q -o /tmp/gradle.zip -d /tmp
    export PATH=/tmp/gradle-8.8/bin:$PATH
  fi
  gradle wrapper --gradle-version 8.8
fi
chmod +x gradlew
./gradlew build
cp build/libs/fragmented-1.0.0.jar ./Fragmented-1.0.0.jar
echo "DONE -> $(pwd)/Fragmented-1.0.0.jar"
